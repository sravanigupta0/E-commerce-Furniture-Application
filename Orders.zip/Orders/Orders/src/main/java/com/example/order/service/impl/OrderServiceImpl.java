package com.example.order.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.order.dao.OrderRepository;
import com.example.order.dto.OrderDto;
import com.example.order.entities.Order;
import com.example.order.mapper.OrderMapper;
import com.example.order.service.OrderService;

// Implementation of the OrderService interface.
@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	OrderRepository orderRepository;

	//  Implementation of the OrderService interface.
	@Override
	public Order findById(Long OrderId) {

		return orderRepository.findById(OrderId).orElseThrow();
	}

	//Retrieves all orders.
	@Override
	public List<Order> findAll() {

		return orderRepository.findAll();
	}

	// Deletes an order by its ID.
	@Override
	public void deleteById(Long OrderId) {
		Order order = findById(OrderId);
		orderRepository.delete(order);

	}

	//Updates an existing order with new details.
	@Override
	public Order update(Order newOrd, Long OrderId) {

		Order oldData = findById(OrderId);
		oldData.setOrderId(newOrd.getOrderId());
		oldData.setFurnitureType(newOrd.getFurnitureType());
		oldData.setCustomerId(newOrd.getCustomerId());
		oldData.setCustomerAddress(newOrd.getCustomerAddress());
		oldData.setCustomerPhoneNumber(newOrd.getCustomerPhoneNumber());
		oldData.setEmail(newOrd.getEmail());
		return orderRepository.save(oldData);
	}

	//Saves a new order based on the provided OrderDto.
	@Override
	public Order save(OrderDto ord) {
		Order o = OrderMapper.OrderDtoToOrders(ord);
		orderRepository.save(o);
		return o;

	}

}
