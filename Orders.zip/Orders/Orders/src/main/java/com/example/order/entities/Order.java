package com.example.order.entities;

import java.time.LocalDate;
import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity // Indicates that this class is a JPA entity
@Table(name = "Orders") // Specifies the name of the database table
public class Order {
	@Id // Specifies the primary key of the entity
	@GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-generates the primary key value
	private Long orderId;

	@NotNull(message = "Customer ID must not be null.") // Ensures the customer ID is not null
	private Long customerId;

	@NotBlank(message = "Furniture type must not be blank.") // Ensures the furniture type is not blank
	private String furnitureType;

	@NotNull(message = "Order date must not be null.") // Ensures the order date is not null
	@PastOrPresent(message = "Order date must be in the past or present.") // Validates that the order date is not in
																			// the future
	private LocalDate orderedDate;

	@NotBlank(message = "Customer name must not be blank.") // Ensures the customer name is not blank
	private String customerName;

	@NotBlank(message = "Customer address must not be blank.") // Ensures the customer address is not blank
	private String customerAddress;

	@Email(message = "Invalid email address.") // Validates that the email format is correct
	private String email;

	@Positive(message = "Customer phone number must be positive.") // Ensures the phone number is positive
	private Long customerPhoneNumber;

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getFurnitureType() {
		return furnitureType;
	}

	public void setFurnitureType(String furnitureType) {
		this.furnitureType = furnitureType;
	}

	public LocalDate getOrderedDate() {
		return orderedDate;
	}

	public void setOrderedDate(LocalDate orderedDate) {
		this.orderedDate = orderedDate;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getCustomerPhoneNumber() {
		return customerPhoneNumber;
	}

	public void setCustomerPhoneNumber(Long customerPhoneNumber) {
		this.customerPhoneNumber = customerPhoneNumber;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

}