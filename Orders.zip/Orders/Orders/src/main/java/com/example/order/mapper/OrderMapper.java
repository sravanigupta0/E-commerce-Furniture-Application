package com.example.order.mapper;

import java.time.LocalDate;

import com.example.order.dto.OrderDto;
import com.example.order.entities.Order;

// Mapper class for converting OrderDto to Order entity.
public class OrderMapper {
	
	// Converts an OrderDto object to an Order entity.
	public static Order OrderDtoToOrders(OrderDto ord) {
		Order order = new Order();
		
		// Set the customer ID from the DTO
		order.setCustomerId(ord.getCustomerId());
		
		// Set the furniture type from the DTO
		order.setFurnitureType(ord.getFurnitureType());
		
		// Set the customer name from the DTO
		order.setCustomerName(ord.getCustomerName());
		
		// Set the customer address from the DTO
		order.setCustomerAddress(ord.getCustomerAddress());
		
		// Set the customer phone number from the DTO
		order.setCustomerPhoneNumber(ord.getCustomerPhoneNumber());
		
		// Set the email from the DTO
		order.setEmail(ord.getEmail());
		
		// Set the ordered date to the current date
		order.setOrderedDate(LocalDate.now());
		return order;
	}
}
