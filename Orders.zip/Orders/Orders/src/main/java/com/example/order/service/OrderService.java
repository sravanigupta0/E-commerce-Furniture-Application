package com.example.order.service;

import java.util.List;

import com.example.order.dto.OrderDto;
import com.example.order.entities.Order;

//Service interface for managing Order operations.
public interface OrderService {

	// Saves a new order based on the provided OrderDto.
	Order save(OrderDto ord);

	// Finds an order by its ID.
	Order findById(Long OrderId);

	// Retrieves all orders.
	List<Order> findAll();

	// Deletes an order by its ID.
	void deleteById(Long OrderId);

	// Updates an existing order with new details.
	Order update(Order newOrd, Long OrderId);

}
