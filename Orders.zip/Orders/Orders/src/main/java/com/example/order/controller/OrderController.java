package com.example.order.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.order.dto.OrderDto;
import com.example.order.entities.Order;

import com.example.order.service.OrderService;

import jakarta.validation.Valid;

// REST controller for managing orders
@RestController
@RequestMapping("/orders")
public class OrderController {

	@Autowired
	OrderService orderService;

	// Saves a new order
	@PostMapping()
	public ResponseEntity<Order> save(@Valid @RequestBody OrderDto ord) {
		Order order = orderService.save(ord);
		return new ResponseEntity<Order>(order, HttpStatus.CREATED);
	}

	// Retrieves a list of all orders
	// http://localhost:8087/orders/findorders
	@GetMapping("/findorders")
	public ResponseEntity<List<Order>> findAll() {
		return new ResponseEntity<List<Order>>(orderService.findAll(), HttpStatus.OK);
	}

	// Finds an order by its ID
	// http://localhost:8087/orders/findbyid/
	@GetMapping("/findbyid/{OrderId}")
	public ResponseEntity<Order> findById(@PathVariable("OrderId") Long OrderId) {
		return new ResponseEntity<Order>(orderService.findById(OrderId), HttpStatus.OK);
	}

	// Updates an existing order by its ID
	// http://localhost:8087/orders/updatebyid/
	@PutMapping("/updatebyid/{OrderId}")
	public ResponseEntity<Order> updateById(@PathVariable("OrderId") Long OrderId, @Valid @RequestBody Order newOrd) {
		return new ResponseEntity<Order>(orderService.update(newOrd, OrderId), HttpStatus.OK);
	}

	// Deletes an order by its ID
	// http://localhost:8087/orders/deletebyid/
	@DeleteMapping("/deletebyid/{OrderId}")
	public ResponseEntity<HttpStatus> deleteById(@PathVariable("OrderId") Long OrderId) {
		orderService.deleteById(OrderId);
		return new ResponseEntity<HttpStatus>(HttpStatusCode.valueOf(200));
	}

}
