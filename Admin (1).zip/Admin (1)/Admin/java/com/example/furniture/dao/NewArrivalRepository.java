package com.example.furniture.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.furniture.entities.NewArrival;

public interface NewArrivalRepository extends JpaRepository<NewArrival, Long> {

	NewArrival save(NewArrival arrival);

}
