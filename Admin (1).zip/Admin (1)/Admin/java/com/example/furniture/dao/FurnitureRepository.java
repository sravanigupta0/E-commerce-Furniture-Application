package com.example.furniture.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.furniture.entities.Furniture;

public interface FurnitureRepository extends JpaRepository<Furniture, Long> {
	Furniture findByFurnitureName(String furnitureName);
}
