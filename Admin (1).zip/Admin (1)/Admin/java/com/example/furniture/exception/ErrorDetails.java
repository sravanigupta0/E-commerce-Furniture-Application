package com.example.furniture.exception;

import java.util.Date;

public class ErrorDetails {
	 // A message describing the error
	private String message;
	
	// The date and time when the error occurred
	private Date date;
	
	 // The path of the request that caused the error
	private String path;
	
	
	public ErrorDetails() {
		super();
	}
	public ErrorDetails(String message, Date date, String path) {
		super();
		this.message = message;
		this.date = date;
		this.path = path;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	
	
}


