package com.example.furniture.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.furniture.entities.Furniture;
import com.example.furniture.service.FurnitureService;

import jakarta.validation.Valid;

//Controller for managing furniture items.
@RestController
@RequestMapping("/furnitures")

public class FurnitureController {

	@Autowired
	FurnitureService furnitureService;

	// Constructs a FurnitureController with the specified FurnitureService.
	public FurnitureController(FurnitureService service) {
		super();
		this.furnitureService = service;
	}

	// Saves a new furniture item.
	@PostMapping()
	public ResponseEntity<Furniture> save(@Valid @RequestBody Furniture furniture) {
		Furniture newFur = furnitureService.save(furniture);
		return new ResponseEntity<Furniture>(newFur, HttpStatus.CREATED);
	}

	// Retrieves a list of all furniture items.
	// http://localhost:8086/furnitures/findfurnitures
	@GetMapping("/findfurnitures")
	public ResponseEntity<List<Furniture>> findAll() {
		return new ResponseEntity<List<Furniture>>(furnitureService.findAll(), HttpStatus.OK);
	}

	// Finds a furniture item by its ID.
	// http://localhost:8086/furnitures/findbyid/
	@GetMapping("/findbyid/{furnitureId}")
	public ResponseEntity<Furniture> findById(@PathVariable("furnitureId") Long furnitureId) {
		return new ResponseEntity<Furniture>(furnitureService.findById(furnitureId), HttpStatus.OK);
	}

	// Deletes a furniture item by its ID.
	// http://localhost:8086/furnitures/deletebyid/
	@DeleteMapping("/deletebyid/{furnitureId}")
	public ResponseEntity<HttpStatus> deleteById(@PathVariable("furnitureId") Long id) {
		furnitureService.deleteById(id);
		return new ResponseEntity<HttpStatus>(HttpStatusCode.valueOf(200));
	}

	// Updates a furniture item by its ID.
	// http://localhost:8086/furnitures/updatebyid/
	@PutMapping("/updatebyid/{furnitureId}")
	public ResponseEntity<Furniture> update(@PathVariable("furnitureId") Long furnitureId, @Valid

	@RequestBody Furniture newFurniture) {
		return new ResponseEntity<Furniture>(furnitureService.update(newFurniture, furnitureId), HttpStatus.OK);
	}

	// Finds a furniture item by its name.
	// http://localhost:8086/furnitures/byname/
	@GetMapping("/findbyname/{furnitureName}")
	public ResponseEntity<Furniture> findByFurnitureName(@PathVariable("furnitureName") String furnitureName) {
		return new ResponseEntity<Furniture>(furnitureService.findByFurnitureName(furnitureName), HttpStatus.OK);
	}
}
