package com.example.furniture.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.furniture.entities.NewArrival;
import com.example.furniture.service.NewArrivalService;

import jakarta.validation.Valid;

//Controller for managing new arrivals in the furniture catalog.
@RestController
@RequestMapping("/furnitures/newarrival")
public class NewArrivalController {
	@Autowired
	NewArrivalService newarrivalService;

	// Constructs a NewArrivalController with the specified NewArrivalService.
	public NewArrivalController(NewArrivalService service) {
		super();
		this.newarrivalService = service;
	}

	// Saves a new arrival record.
	@PostMapping()
	public ResponseEntity<NewArrival> save(@Valid @RequestBody NewArrival Arrival) {
		NewArrival newArrival = newarrivalService.save(Arrival);
		return new ResponseEntity<NewArrival>(newArrival, HttpStatus.CREATED);
	}

	// Retrieves a list of all new arrivals.
	// http://localhost:8086/furnitures/newarrival/findarrival
	@GetMapping("/findarrival")
	public ResponseEntity<List<NewArrival>> findAll() {
		return new ResponseEntity<List<NewArrival>>(newarrivalService.findAll(), HttpStatus.OK);
	}

	// Finds a new arrival record by its ID.
	// http://localhost:8086/furnitures/newarrival/findbyid/
	@GetMapping("/findbyid/{newArrivalId}")
	public ResponseEntity<NewArrival> findById(@PathVariable("newArrivalId") Long newArrivalId) {
		System.out.println("hello");
		return new ResponseEntity<NewArrival>(newarrivalService.findById(newArrivalId), HttpStatus.OK);
	}

	// Updates a new arrival record by its ID.
	// http://localhost:8086/furnitures/newarrival/updatebyid/
	@PutMapping("/updatebyid{newArrivalId}")
	public ResponseEntity<NewArrival> updateById(@PathVariable("newArrivalId") Long newArrivalId,
			@Valid @RequestBody NewArrival newArrival) {
		return new ResponseEntity<NewArrival>(newarrivalService.update(newArrival, newArrivalId), HttpStatus.OK);
	}

	// Deletes a new arrival record by its ID.
	// http://localhost:8086/furnitures/newarrival/deletebyid/
	@DeleteMapping("/deletebyid/{newArrivalid}")
	public ResponseEntity<HttpStatus> deleteById(@PathVariable("newArrivalid") Long id) {
		newarrivalService.deleteById(id);
		return new ResponseEntity<HttpStatus>(HttpStatusCode.valueOf(200));
	}

}
