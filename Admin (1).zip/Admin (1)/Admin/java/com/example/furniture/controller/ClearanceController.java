package com.example.furniture.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.furniture.entities.Clearance;
import com.example.furniture.service.ClearanceService;

import jakarta.validation.Valid;

//Controller for managing clearance items.
@RestController
@RequestMapping("/furnitures/clearance")


public class ClearanceController {
	@Autowired
	ClearanceService clearanceService;

	//Constructs a ClearanceController with the specified ClearanceService.
	public ClearanceController(ClearanceService service) {
		super();
		this.clearanceService = service;
	}

	// Saves a new clearance item.
	@PostMapping()
	public ResponseEntity<Clearance> save(@Valid @RequestBody Clearance clear) {
		Clearance newClear = clearanceService.save(clear);
		return new ResponseEntity<Clearance>(newClear, HttpStatus.CREATED);
	}

	//  Retrieves a list of all clearance items.
	// http://localhost:8086/furnitures/clearance/findclearances
	@GetMapping("/findclearances")
	public ResponseEntity<List<Clearance>> findAll() {
		return new ResponseEntity<List<Clearance>>(clearanceService.findAll(), HttpStatus.OK);
	}

	// Finds a clearance item by its ID.
	// http://localhost:8086/furnitures/clearance/findbyid/
	@GetMapping("/findbyid/{clearanceId}")
	public ResponseEntity<Clearance> findById(@PathVariable("clearanceId") Long clearanceId) {
		return new ResponseEntity<Clearance>(clearanceService.findById(clearanceId), HttpStatus.OK);
	}

	// Updates a clearance item by its ID.
	// http://localhost:8086/furnitures/clearance/updatebyid/
	@PutMapping("/updatebyid/{clearanceId}")
	public ResponseEntity<Clearance> updateById(@PathVariable("clearanceId") Long clearanceId,
			@Valid @RequestBody Clearance newClear) {
		return new ResponseEntity<Clearance>(clearanceService.update(newClear, clearanceId), HttpStatus.OK);
	}
	
    // Deletes a clearance item by its ID.
	// http://localhost:8086/furnitures/clearance/deletebyid/
	@DeleteMapping("/deletebyid/{id}")
	public ResponseEntity<HttpStatus> deleteById(@PathVariable("id") Long id) {
		clearanceService.deleteById(id);
		return new ResponseEntity<HttpStatus>(HttpStatusCode.valueOf(200));
	}
}
