package com.example.furniture.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity // Indicates that this class is a JPA entity
@Table(name = "Clearances") // Specifies the name of the database table
public class Clearance {
	@Id // Specifies the primary key of the entity
	@GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-generates the primary key value
	private Long clearanceId; // Unique identifier for each clearance record

	@NotBlank(message = "Clearance type must not be empty.") // Ensures the clearance type is not empty
	private String clearanceType; // Type of the clearance

	@DecimalMin(value = "0.0", inclusive = true, message = "Discount must be at least 0%.") // Validates that discount
																							// is at least 0%
	@DecimalMax(value = "100.0", inclusive = true, message = "Discount must not exceed 100%.") // Validates that
																								// discount does not
																								// exceed 100%
	private float discount; // Discount percentage applied during clearance

	@FutureOrPresent(message = "Clearance date must be in the present or future.") // Validates that the clearance date
																					// is today or in the future
	private Date clearanceDate; // Date when the clearance is applicable

	public Long getClearanceId() {
		return clearanceId;
	}

	public void setClearanceId(long i) {
		this.clearanceId = i;
	}

	public String getClearanceType() {
		return clearanceType;
	}

	public void setClearanceType(String clearanceType) {
		this.clearanceType = clearanceType;
	}

	public float getDiscount() {
		return discount;
	}

	public void setDiscount(float discount) {
		this.discount = discount;
	}

	public Date getClearancedate() {
		return clearanceDate;
	}

	public void setClearancedate(Date clearancedate) {
		this.clearanceDate = clearancedate;
	}

}
