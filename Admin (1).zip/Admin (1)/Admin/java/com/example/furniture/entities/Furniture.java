package com.example.furniture.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Furnitures")
public class Furniture {
	@Id // Specifies the primary key of the entity
	@GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-generates the primary key value
	private Long furnitureId;

	@NotBlank(message = "Furniture name must not be empty.") // Ensures the furniture name is not empty
	private String furnitureName;

	private boolean availability;// Indicates if the furniture is available for purchase

	@DecimalMin(value = "0.0", inclusive = true, message = "Furniture price must not be negative.") // Validates that
																									// price is
																									// non-negative
	private double furniturePrice;

	public Long getFurnitureId() {
		return furnitureId;
	}

	public void setFurnitureId(Long furnitureId) {
		this.furnitureId = furnitureId;
	}

	public String getFurnitureName() {
		return furnitureName;
	}

	public void setFurnitureName(String furnitureName) {
		this.furnitureName = furnitureName;
	}

	public boolean isAvailability() {
		return availability;
	}

	public void setAvailability(boolean availability) {
		this.availability = availability;
	}

	public double getFurniturePrice() {
		return furniturePrice;
	}

	public void setFurniturePrice(double furniturePrice) {
		this.furniturePrice = furniturePrice;
	}

}
