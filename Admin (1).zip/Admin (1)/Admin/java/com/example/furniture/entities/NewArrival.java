package com.example.furniture.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity // Indicates that this class is a JPA entity
@Table(name = "NewArrivals")
public class NewArrival {
	@Id // Specifies the primary key of the entity
	@GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-generates the primary key value
	private long newArrivalId; // Unique identifier for each new arrival

	@NotNull(message = "New Arrival Date must not be null.") // Ensures the new arrival date is not null
	@FutureOrPresent(message = "New Arrival Date must be in the present or future.") // Validates that the date is today
																						// or in the future
	private Date newArrivalDate; // Date when the item is marked as a new arrival

	@NotBlank(message = "New Arrival Type must not be empty.") // Ensures the new arrival type is not empty
	private String newArrivalType; // Type of the new arrival (e.g., furniture, electronics)

	@DecimalMin(value = "0.0", inclusive = true, message = "Price must not be negative.") // Validates that price is
																							// non-negative
	private double price; // Price of the new arrival item

	public long getNewArrivalId() {
		return newArrivalId;
	}

	public void setNewArrivalId(long newArrivalId) {
		this.newArrivalId = newArrivalId;
	}

	public Date getNewArrivalDate() {
		return newArrivalDate;
	}

	public void setNewArrivalDate(Date newArrivalDate) {
		this.newArrivalDate = newArrivalDate;
	}

	public String getNewArrivalType() {
		return newArrivalType;
	}

	public void setNewArrivalType(String newArrivalType) {
		this.newArrivalType = newArrivalType;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
