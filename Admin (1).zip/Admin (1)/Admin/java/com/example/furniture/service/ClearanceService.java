package com.example.furniture.service;

import java.util.List;

import com.example.furniture.entities.Clearance;
import com.example.furniture.entities.Furniture;

//Service interface for managing clearance records.
public interface ClearanceService {
	
	// Saves a new clearance record.
	Clearance save(Clearance clear);

	// Retrieves a clearance record by its ID.
	Clearance findById(Long clearanceId);

    //	Retrieves all clearance records.
	List<Clearance> findAll();

    //	Deletes a clearance record by its ID.
	void deleteById(Long id);
	
    //  Updates an existing clearance record.
	Clearance update(Clearance newClear, Long clearanceId);

}
