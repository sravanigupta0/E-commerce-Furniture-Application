package com.example.furniture.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.furniture.dao.FurnitureRepository;
import com.example.furniture.entities.Furniture;
import com.example.furniture.service.FurnitureService;

@Service
public class FurnitureSeviceImpl implements FurnitureService {

	@Autowired
	FurnitureRepository furnitureRepository;

	//Saves a new furniture record.
	@Override
	public Furniture save(Furniture furniture) {

		return furnitureRepository.save(furniture);
	}

	// Retrieves a furniture record by its ID.
	@Override
	public Furniture findById(Long furnitureId) {

		return furnitureRepository.findById(furnitureId)
				.orElseThrow(() -> new RuntimeException("Resource for ID :" + furnitureId + " Not Available"));
	}

	//Retrieves all furniture records.
	@Override
	public List<Furniture> findAll() {

		return furnitureRepository.findAll();
	}

	//Updates an existing furniture record.
	@Override
	public Furniture update(Furniture newFur, Long furnitureId) {
		Furniture oldData = findById(furnitureId);
		oldData.setFurnitureId(newFur.getFurnitureId());
		oldData.setFurnitureName(newFur.getFurnitureName());
		oldData.setFurniturePrice(newFur.getFurniturePrice());
		oldData.setAvailability(newFur.isAvailability());

		return furnitureRepository.save(oldData);
	}

	//Deletes a furniture record by its ID.
	@Override
	public void deleteById(Long id) {
		// TODO Auto-generated method stub
		Furniture furniture = findById(id);
		furnitureRepository.delete(furniture);
	}

	//Retrieves a furniture record by its name.
	@Override
	public Furniture findByFurnitureName(String furnitureName) {
		// TODO Auto-generated method stub
		return furnitureRepository.findByFurnitureName(furnitureName);
	}
}
