package com.example.furniture.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.furniture.dao.NewArrivalRepository;
import com.example.furniture.entities.NewArrival;
import com.example.furniture.service.NewArrivalService;

@Service
public class NewArrivalServiceImpl implements NewArrivalService {
	@Autowired
	NewArrivalRepository newarrivalRepository;

	//Saves a new arrival record.
	@Override
	public NewArrival save(NewArrival arrival) {
		// TODO Auto-generated method stub
		return newarrivalRepository.save(arrival);
	}

	//Retrieves a new arrival record by its ID.
	@Override
	public NewArrival findById(Long newArrivalId) {
		// TODO Auto-generated method stub
		return newarrivalRepository.findById(newArrivalId)
				.orElseThrow(() -> new RuntimeException("Resource for ID :" + newArrivalId + " Not Available"));
	}

	// Retrieves all new arrival records.
	@Override
	public List<NewArrival> findAll() {
		// TODO Auto-generated method stub
		return newarrivalRepository.findAll();
	}

	//Updates an existing new arrival record.
	@Override
	public NewArrival update(NewArrival newArrival, Long newArrivalId) {
		// TODO Auto-generated method stub
		NewArrival oldData = findById(newArrivalId);
		oldData.setNewArrivalId(newArrival.getNewArrivalId());
		oldData.setNewArrivalDate(newArrival.getNewArrivalDate());
		oldData.setNewArrivalType(newArrival.getNewArrivalType());
		oldData.setPrice(newArrival.getPrice());
		return newarrivalRepository.save(oldData);
	}

	// Deletes a new arrival record by its ID.
	@Override
	public void deleteById(Long id) {
		// TODO Auto-generated method stub
		NewArrival newArrival = findById(id);
		newarrivalRepository.delete(newArrival);
	}

}
