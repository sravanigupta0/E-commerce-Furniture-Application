package com.example.furniture.service;

import java.util.List;

import com.example.furniture.entities.Furniture;

//Service interface for managing furniture records.
public interface FurnitureService {
	
	//Saves a new furniture record.
	Furniture save(Furniture furniture);

	//Retrieves a furniture record by its ID.
	Furniture findById(Long furnitureId);

	//Retrieves a furniture record by its name.
	Furniture findByFurnitureName(String furnitureName);

	//Retrieves all furniture records.
	List<Furniture> findAll();

	//Deletes a furniture record by its ID.
	void deleteById(Long id);

	//Updates an existing furniture record.
	Furniture update(Furniture newFur, Long furnitureId);

}
