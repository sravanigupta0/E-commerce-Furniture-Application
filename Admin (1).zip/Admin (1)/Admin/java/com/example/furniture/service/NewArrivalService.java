package com.example.furniture.service;

import java.util.List;

import com.example.furniture.entities.NewArrival;

//Service interface for managing new arrival records.
public interface NewArrivalService {
	
	//Saves a new arrival record.
	NewArrival save(NewArrival arrival);

	//Retrieves all new arrival records
	List<NewArrival> findAll();

	//Retrieves a new arrival record by its ID.
	NewArrival findById(Long newArrivalId);

	//Deletes a new arrival record by its ID.
	void deleteById(Long id);

	//Updates an existing new arrival record.
	NewArrival update(NewArrival newArrival, Long newArrivalId);

}
