package com.example.furniture.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.furniture.dao.ClearanceRepository;
import com.example.furniture.entities.Clearance;
import com.example.furniture.service.ClearanceService;

@Service
public class ClearanceServiceImpl implements ClearanceService {
	@Autowired
	ClearanceRepository clearanceRepository;

	//Saves a new clearance record.
	@Override
	public Clearance save(Clearance clear) {
		// TODO Auto-generated method stub
		return clearanceRepository.save(clear);
	}

	//Retrieves a clearance record by its ID.
	@Override
	public Clearance findById(Long clearanceId) {
		// TODO Auto-generated method stub
		return clearanceRepository.findById(clearanceId)
				.orElseThrow(() -> new RuntimeException("Resource for ID :" + clearanceId + " Not Available"));
	}

	//Retrieves all clearance records.
	@Override
	public List<Clearance> findAll() {
		// TODO Auto-generated method stub
		return clearanceRepository.findAll();
	}

	//Updates an existing clearance record.
	@Override
	public Clearance update(Clearance newClear, Long clearanceId) {
		// TODO Auto-generated method stub
		Clearance oldData = findById(clearanceId);
		oldData.setClearanceId(newClear.getClearanceId());
		oldData.setClearancedate(newClear.getClearancedate());
		oldData.setClearanceType(newClear.getClearanceType());
		oldData.setDiscount(newClear.getDiscount());
		return clearanceRepository.save(oldData);
	}

	//Deletes a clearance record by its ID.
	@Override
	public void deleteById(Long id) {
		// TODO Auto-generated method stub
		Clearance clear = findById(id);
		clearanceRepository.delete(clear);
	}

}
