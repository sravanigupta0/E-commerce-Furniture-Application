
package com.example.repository.test;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Set;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.example.furniture.dao.FurnitureRepository;
import com.example.furniture.entities.Furniture;


@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class FurnitureRepositoryTest {

	
	

	    @Autowired
	    private FurnitureRepository repository;

	    Furniture getDummyFurniture() {
	        Furniture furniture = new Furniture();
	        furniture.setFurnitureName("Sofa");
	        furniture.setAvailability(true);
	        furniture.setFurniturePrice(299.99);
	        return furniture;
	    }

	    List<Furniture> getDummyFurnitureList() {
	        Furniture furniture1 = new Furniture();
	        furniture1.setFurnitureName("Chair");
	        furniture1.setAvailability(true);
	        furniture1.setFurniturePrice(49.99);

	        Furniture furniture2 = new Furniture();
	        furniture2.setFurnitureName("Table");
	        furniture2.setAvailability(false);
	        furniture2.setFurniturePrice(199.99);

	        return Arrays.asList(furniture1, furniture2);
	    }

	    @BeforeEach
	    public void setup() {
	        repository.deleteAll(); // Ensure a clean state before each test
	    }

	    @Test
	    @DisplayName("Unit test to save Furniture Operation")
	    public void givenFurnitureObject_whenSave_thenReturnSavedFurniture() {
	        // Given Furniture Object
	        Furniture furniture = getDummyFurniture();
	        // When
	        Furniture savedFurniture = repository.save(furniture);
	        // Then verify output
	        assertNotNull(savedFurniture, "Furniture should not be null");
	    }

	    @DisplayName("JUnit test for get all furniture operation")
	    @Test
	    public void givenFurnitureList_whenFindAll_thenFurnitureList() {
	        // given - precondition or setup
	        getDummyFurnitureList().forEach(repository::save);

	        // when - action or the behaviour that we are going to test
	        List<Furniture> furnitureList = repository.findAll();

	        // then - verify the output
	        Assertions.assertThat(furnitureList).isNotNull();
	        Assertions.assertThat(furnitureList.size()).isEqualTo(2);
	    }

	    @DisplayName("JUnit test for get Furniture by id operation")
	    @Test
	    public void givenFurnitureObject_whenFindById_thenReturnFurnitureObject() {
	        // given - precondition or setup
	        List<Furniture> list = getDummyFurnitureList();
	        list.forEach(repository::save);
	        Furniture furniture = list.get(0);

	        // when - action or the behaviour that we are going to test
	        Optional<Furniture> foundFurniture = repository.findById(furniture.getFurnitureId());

	        // then - verify the output
	        assertNotNull(foundFurniture.get(), "Furniture cannot be null");
	    }

	    @DisplayName("JUnit test for get Furniture by id operation Negative Test")
	    @Test
	    public void givenFurnitureObject_whenFindById_thenThrowException() {
	        // given - precondition or setup
	        List<Furniture> list = getDummyFurnitureList();
	        list.forEach(repository::save);

	        // when - action or the behaviour that we are going to test
	        Optional<Furniture> foundFurniture = repository.findById(10L); // Assuming 10L does not exist

	        // then - verify the output
	        assertThrows(NoSuchElementException.class, () -> foundFurniture.get());
	    }

	    @DisplayName("JUnit test for update Furniture operation")
	    @Test
	    public void givenFurnitureObject_whenUpdateFurniture_thenReturnUpdatedFurniture() {
	        // given - precondition or setup
	        Furniture furniture = getDummyFurniture();
	        repository.save(furniture);

	        // when - action or the behaviour that we are going to test
	        Furniture savedFurniture = repository.findById(furniture.getFurnitureId()).get();
	        savedFurniture.setFurnitureName("Updated Sofa");
	        savedFurniture.setFurniturePrice(349.99);
	        Furniture updatedFurniture = repository.save(savedFurniture);

	        // then - verify the output
	        Assertions.assertThat(updatedFurniture.getFurnitureName()).isEqualTo("Updated Sofa");
	        Assertions.assertThat(updatedFurniture.getFurniturePrice()).isEqualTo(349.99);
	    }

	    @DisplayName("JUnit test for delete Furniture operation")
	    @Test
	    public void givenFurnitureObject_whenDelete_thenRemoveFurniture() {
	        // given - precondition or setup
	        Furniture furniture = getDummyFurniture();
	        repository.save(furniture);

	        // when - action or the behaviour that we are going to test
	        repository.deleteById(furniture.getFurnitureId());
	        Optional<Furniture> optionalFurniture = repository.findById(furniture.getFurnitureId());

	        // then - verify the output
	        assertTrue(optionalFurniture.isEmpty());
	    }
}