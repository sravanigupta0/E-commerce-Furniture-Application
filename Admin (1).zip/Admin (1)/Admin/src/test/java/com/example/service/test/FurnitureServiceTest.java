package com.example.service.test;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.furniture.dao.FurnitureRepository;
import com.example.furniture.entities.Furniture;
import com.example.furniture.exception.ResourceNotFoundException;
import com.example.furniture.service.impl.FurnitureSeviceImpl;

@ExtendWith(MockitoExtension.class)

public class FurnitureServiceTest {

	@Mock
	private FurnitureRepository repository;

	@InjectMocks
	private FurnitureSeviceImpl service;

	private Furniture getDummyFurniture() {
		Furniture furniture = new Furniture();
		furniture.setFurnitureId(1L);
		furniture.setFurnitureName("Sofa");
		furniture.setAvailability(true);
		furniture.setFurniturePrice(299.99);
		return furniture;
	}

	private List<Furniture> getDummyFurnitureList() {
		return Arrays.asList(new Furniture(), new Furniture());
	}

	@BeforeEach
	public void setup() {
		// Pre-test setup if needed
	}

	// JUnit test for save method
	@DisplayName("JUnit test for save Furniture method")
	@Test
	public void givenFurnitureObject_whenSaveFurniture_thenReturnFurnitureObject() {
		// Given
		Furniture furniture = getDummyFurniture();
		when(repository.save(furniture)).thenReturn(furniture);

		// When
		Furniture savedFurniture = service.save(furniture);

		// Then
		Assertions.assertThat(savedFurniture).isNotNull();
	}

	@DisplayName("JUnit test for findAll method")
	@Test
	public void givenFurnitureList_whenGetAllFurnitures_thenReturnFurnituresList() {
		// Given
		when(repository.findAll()).thenReturn(getDummyFurnitureList());

		// When
		List<Furniture> furnitureList = service.findAll();

		// Then
		Assertions.assertThat(furnitureList).isNotNull();
		Assertions.assertThat(furnitureList.size()).isEqualTo(2);
	}

	@DisplayName("JUnit test for findAll method (negative scenario)")
	@Test
	public void givenEmptyFurnituresList_whenGetAllFurnitures_thenReturnEmptyFurnituresList() {
		// Given
		given(repository.findAll()).willReturn(Collections.emptyList());

		// When
		List<Furniture> furnitureList = service.findAll();

		// Then
		Assertions.assertThat(furnitureList).isEmpty();
		Assertions.assertThat(furnitureList.size()).isEqualTo(0);
	}

	@DisplayName("JUnit test for findById method")
	@Test
	public void givenFurnitureId_whenGetFurnitureById_thenReturnFurnitureObject() {
		// Given
		given(repository.findById(1L)).willReturn(Optional.of(getDummyFurniture()));

		// When
		Furniture foundFurniture = service.findById(1L);

		// Then
		Assertions.assertThat(foundFurniture).isNotNull();
	}

	@DisplayName("JUnit test for findById method Exception")
	@Test
	public void givenFurnitureId_whenGetFurnitureById_thenReturnException() {
		// Given
		given(repository.findById(1L)).willReturn(Optional.empty());

		// When & Then
		assertThrows(ResourceNotFoundException.class, () -> service.findById(1L));
	}

	@DisplayName("JUnit test for update method")
	@Test
	public void givenFurnitureObject_whenUpdateFurniture_thenReturnUpdatedFurniture() {
		// Given
		Furniture furniture = getDummyFurniture();
		given(repository.save(furniture)).willReturn(furniture);
		given(repository.findById(1L)).willReturn(Optional.of(furniture));
		furniture.setFurnitureName("Updated Sofa");
		furniture.setFurniturePrice(349.99);

		// When
		Furniture updatedFurniture = service.update(furniture, 1L);

		// Then
		Assertions.assertThat(updatedFurniture.getFurnitureName()).isEqualTo("Updated Sofa");
		Assertions.assertThat(updatedFurniture.getFurniturePrice()).isEqualTo(349.99);
	}

	@DisplayName("JUnit test for deleteById method")
	@Test
	public void givenFurnitureId_whenDeleteFurniture_thenNothing() {
		// Given
		long Id = 1L;
		Furniture furniture = getDummyFurniture();
		given(repository.findById(1L)).willReturn(Optional.of(furniture));
		willDoNothing().given(repository).delete(furniture);

		// When
		service.deleteById(Id);

		// Then
		verify(repository, times(1)).delete(furniture);
	}
}
