package com.example.repository.test;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.example.furniture.dao.NewArrivalRepository;
import com.example.furniture.entities.NewArrival;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class NewArrivalRepositoryTest {
	@Autowired
	private NewArrivalRepository repository;

	// Helper method to create a dummy NewArrival object
	private NewArrival getDummyNewArrival() {
		return new NewArrival();
	}

	// Helper method to create a list of dummy NewArrival objects
	private List<NewArrival> getDummyNewArrivalList() {
		return Arrays.asList(new NewArrival(), new NewArrival());
	}

	@BeforeEach
	public void setup() {
		// Clear the repository before each test if needed
		repository.deleteAll();
	}

	@Test
	@DisplayName("Unit test to save NewArrival Operation")
	public void givenNewArrivalObject_whenSave_thenReturnSavedNewArrival() {
		// Given NewArrival Object
		NewArrival newArrival = getDummyNewArrival();
		// When
		NewArrival savedNewArrival = repository.save(newArrival);
		// Then verify output
		assertNotNull(savedNewArrival, "NewArrival should not be null");
	}

	@DisplayName("JUnit test for get all NewArrivals operation")
	@Test
	public void givenNewArrivalsList_whenFindAll_thenNewArrivalsList() {
		// Given
		getDummyNewArrivalList().forEach(s -> repository.save(s));

		// When
		List<NewArrival> newArrivalList = repository.findAll();

		// Then
		Assertions.assertThat(newArrivalList).isNotNull();
		Assertions.assertThat(newArrivalList.size()).isEqualTo(2);
	}

	@DisplayName("JUnit test for get NewArrival by id operation")
	@Test
	public void givenNewArrivalObject_whenFindById_thenReturnNewArrivalObject() {
		// Given
		NewArrival newArrival = getDummyNewArrival();
		NewArrival savedNewArrival = repository.save(newArrival);

		// When
		Optional<NewArrival> foundNewArrival = repository.findById(savedNewArrival.getNewArrivalId());

		// Then
		assertNotNull(foundNewArrival.get(), "NewArrival cannot be null");
	}

	@DisplayName("JUnit test for get NewArrival by id operation Negative Test")
	@Test
	public void givenNewArrivalObject_whenFindById_thenThrowException() {
		// Given
		NewArrival newArrival = getDummyNewArrival();
		repository.save(newArrival);

		// When
		Optional<NewArrival> foundNewArrival = repository.findById(10L); // Assuming this ID does not exist

		// Then
		assertThrows(NoSuchElementException.class, () -> foundNewArrival.get());
	}

	@DisplayName("JUnit test for update NewArrival operation")
	@Test
	public void givenNewArrivalObject_whenUpdateNewArrival_thenReturnUpdatedNewArrival() {
		// Given
		NewArrival newArrival = getDummyNewArrival();
		NewArrival savedNewArrival = repository.save(newArrival);

		// When
		savedNewArrival.setNewArrivalType("Updated Type");
		NewArrival updatedNewArrival = repository.save(savedNewArrival);

		// Then
		Assertions.assertThat(updatedNewArrival.getNewArrivalType()).isEqualTo("Updated Type");
	}

	@DisplayName("JUnit test for delete NewArrival operation")
	@Test
	public void givenNewArrivalObject_whenDelete_thenRemoveNewArrival() {
		// Given
		NewArrival newArrival = getDummyNewArrival();
		NewArrival savedNewArrival = repository.save(newArrival);

		// When
		repository.deleteById(savedNewArrival.getNewArrivalId());
		Optional<NewArrival> optionalNewArrival = repository.findById(savedNewArrival.getNewArrivalId());

		// Then
		Assertions.assertThat(optionalNewArrival).isEmpty();
	}
}
