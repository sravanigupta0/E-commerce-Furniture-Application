package com.example.service.test;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.furniture.dao.NewArrivalRepository;
import com.example.furniture.entities.NewArrival;
import com.example.furniture.exception.ResourceNotFoundException;
import com.example.furniture.service.impl.NewArrivalServiceImpl;

@ExtendWith(MockitoExtension.class)
public class NewArrivalServiceTest {

	@Mock
	private NewArrivalRepository repository;

	@InjectMocks
	private NewArrivalServiceImpl service;

	private NewArrival getDummyNewArrival() {
		NewArrival arrival = new NewArrival();
		arrival.setNewArrivalId(1L);
		arrival.setNewArrivalDate(new Date());
		arrival.setNewArrivalType("New Clothing");
		arrival.setPrice(49.99);
		return arrival;
	}

	private List<NewArrival> getDummyNewArrivalList() {
		return Arrays.asList(new NewArrival(), new NewArrival());
	}

	@BeforeEach
	public void setup() {
		// Pre-test setup if needed
	}

	// JUnit test for save method
	@DisplayName("JUnit test for save NewArrival method")
	@Test
	public void givenNewArrivalObject_whenSaveNewArrival_thenReturnNewArrivalObject() {
		// Given
		NewArrival arrival = getDummyNewArrival();
		when(repository.save(arrival)).thenReturn(arrival);

		// When
		NewArrival savedArrival = service.save(arrival);

		// Then
		Assertions.assertThat(savedArrival).isNotNull();
	}

	@DisplayName("JUnit test for findAll method")
	@Test
	public void givenNewArrivalsList_whenGetAllNewArrivals_thenReturnNewArrivalsList() {
		// Given
		when(repository.findAll()).thenReturn(getDummyNewArrivalList());

		// When
		List<NewArrival> arrivalList = service.findAll();

		// Then
		Assertions.assertThat(arrivalList).isNotNull();
		Assertions.assertThat(arrivalList.size()).isEqualTo(2);
	}

	@DisplayName("JUnit test for findAll method (negative scenario)")
	@Test
	public void givenEmptyNewArrivalsList_whenGetAllNewArrivals_thenReturnEmptyNewArrivalsList() {
		// Given
		given(repository.findAll()).willReturn(Collections.emptyList());

		// When
		List<NewArrival> arrivalList = service.findAll();

		// Then
		Assertions.assertThat(arrivalList).isEmpty();
		Assertions.assertThat(arrivalList.size()).isEqualTo(0);
	}

	@DisplayName("JUnit test for findById method")
	@Test
	public void givenNewArrivalId_whenGetNewArrivalById_thenReturnNewArrivalObject() {
		// Given
		given(repository.findById(1L)).willReturn(Optional.of(getDummyNewArrival()));

		// When
		NewArrival foundArrival = service.findById(1L);

		// Then
		Assertions.assertThat(foundArrival).isNotNull();
	}

	@DisplayName("JUnit test for findById method Exception")
	@Test
	public void givenNewArrivalId_whenGetNewArrivalById_thenReturnException() {
		// Given
		given(repository.findById(1L)).willReturn(Optional.empty());

		// When & Then
		assertThrows(ResourceNotFoundException.class, () -> service.findById(1L));
	}

	@DisplayName("JUnit test for update method")
	@Test
	public void givenNewArrivalObject_whenUpdateNewArrival_thenReturnUpdatedNewArrival() {
		// Given
		NewArrival arrival = getDummyNewArrival();
		given(repository.save(arrival)).willReturn(arrival);
		given(repository.findById(1L)).willReturn(Optional.of(arrival));

		arrival.setNewArrivalType("Updated Electronics");
		arrival.setPrice(159.99);

		// When
		NewArrival updatedArrival = service.update(arrival, 1L);

		// Then
		Assertions.assertThat(updatedArrival.getNewArrivalType()).isEqualTo("Updated Electronics");
		Assertions.assertThat(updatedArrival.getPrice()).isEqualTo(159.99);
	}

	@DisplayName("JUnit test for deleteById method")
	@Test
	public void givenNewArrivalId_whenDeleteNewArrival_thenNothing() {
		// Given
		long Id = 1L;
		NewArrival arrival = getDummyNewArrival();
		given(repository.findById(1L)).willReturn(Optional.of(arrival));
		willDoNothing().given(repository).delete(arrival);

		// When
		service.deleteById(Id);

		// Then
		verify(repository, times(1)).delete(arrival);
	}

}
