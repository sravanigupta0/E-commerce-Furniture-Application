package com.example.repository.test;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.example.furniture.dao.ClearanceRepository;
import com.example.furniture.entities.Clearance;
 

 
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class ClearanceRepositoryTest {
	@Autowired
    private ClearanceRepository repository;
 
    // Helper method to create a dummy Clearance object
    private Clearance getDummyClearance() {
        return new Clearance();
    }
 
    // Helper method to create a list of dummy Clearance objects
    private List<Clearance> getDummyClearanceList() {
        return Arrays.asList(
            new Clearance(),
            new Clearance()
        );
    }
 
    @BeforeEach
    public void setup() {
        // Clear the repository before each test
        repository.deleteAll();
    }
 
    @Test
    @DisplayName("Unit test to save Clearance Operation")
    public void givenClearanceObject_whenSave_thenReturnSavedClearance() {
        // Given Clearance Object
        Clearance clearance = getDummyClearance();
        // When
        Clearance savedClearance = repository.save(clearance);
        // Then verify output
        assertNotNull(savedClearance, "Clearance should not be null");
    }
 
    @DisplayName("JUnit test for get all Clearances operation")
    @Test
    public void givenClearancesList_whenFindAll_thenClearancesList() {
        // Given
        getDummyClearanceList().forEach(s -> repository.save(s));
 
        // When
        List<Clearance> clearanceList = repository.findAll();
 
        // Then
        Assertions.assertThat(clearanceList).isNotNull();
        Assertions.assertThat(clearanceList.size()).isEqualTo(2);
    }
 
    @DisplayName("JUnit test for get Clearance by id operation")
    @Test
    public void givenClearanceObject_whenFindById_thenReturnClearanceObject() {
        // Given
        Clearance clearance = getDummyClearance();
        Clearance savedClearance = repository.save(clearance);
        // When
        Optional<Clearance> foundClearance = repository.findById(savedClearance.getClearanceId());
 
        // Then
        assertNotNull(foundClearance.get(), "Clearance cannot be null");
    }
 
    @DisplayName("JUnit test for get Clearance by id operation Negative Test")
    @Test
    public void givenClearanceObject_whenFindById_thenThrowException() {
        // Given
        Clearance clearance = getDummyClearance();
        repository.save(clearance);
 
        // When
        Optional<Clearance> foundClearance = repository.findById(10L); // Assuming this ID does not exist
 
        // Then
        assertThrows(NoSuchElementException.class, () -> foundClearance.get());
    }
 
    @DisplayName("JUnit test for update Clearance operation")
    @Test
    public void givenClearanceObject_whenUpdateClearance_thenReturnUpdatedClearance() {
        // Given
        Clearance clearance = getDummyClearance();
        Clearance savedClearance = repository.save(clearance);
 
        // When
        savedClearance.setClearanceType("Updated Sale");
        savedClearance.setDiscount(30.0f);
        Clearance updatedClearance = repository.save(savedClearance);
 
        // Then
        Assertions.assertThat(updatedClearance.getClearanceType()).isEqualTo("Updated Sale");
        Assertions.assertThat(updatedClearance.getDiscount()).isEqualTo(30.0f);
    }
 
    @DisplayName("JUnit test for delete Clearance operation")
    @Test
    public void givenClearanceObject_whenDelete_thenRemoveClearance() {
        // Given
        Clearance clearance = getDummyClearance();
        Clearance savedClearance = repository.save(clearance);
 
        // When
        repository.deleteById(savedClearance.getClearanceId());
        Optional<Clearance> optionalClearance = repository.findById(savedClearance.getClearanceId());
 
        // Then
        Assertions.assertThat(optionalClearance).isEmpty();
    }
}