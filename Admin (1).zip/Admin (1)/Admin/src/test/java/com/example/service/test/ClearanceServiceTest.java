package com.example.service.test;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.furniture.dao.ClearanceRepository;
import com.example.furniture.entities.Clearance;
import com.example.furniture.exception.ResourceNotFoundException;
import com.example.furniture.service.impl.ClearanceServiceImpl;

@ExtendWith(MockitoExtension.class)
public class ClearanceServiceTest {

	@Mock
	private ClearanceRepository repository;

	@InjectMocks
	private ClearanceServiceImpl service;

	private Clearance getDummyClearance() {
		Clearance clearance = new Clearance();
		clearance.setClearanceType("Seasonal Sale");
		clearance.setDiscount(20.0f);
		clearance.setClearancedate(new Date());
		return clearance;
	}

	private List<Clearance> getDummyClearanceList() {
		return Arrays.asList(new Clearance(), new Clearance());
	}

	@BeforeEach
	public void setup() {
		// Clear the repository before each test if needed
	}

	// JUnit test for save method
	@DisplayName("JUnit test for save Clearance method")
	@Test
	public void givenClearanceObject_whenSaveClearance_thenReturnClearanceObject() {
		// Given
		Clearance clearance = getDummyClearance();
		when(repository.save(clearance)).thenReturn(clearance);

		// When
		Clearance savedClearance = service.save(clearance);

		// Then
		Assertions.assertThat(savedClearance).isNotNull();
	}

	@DisplayName("JUnit test for findAll method")
	@Test
	public void givenClearancesList_whenGetAllClearances_thenReturnClearancesList() {
		// Given
		when(repository.findAll()).thenReturn(getDummyClearanceList());

		// When
		List<Clearance> clearanceList = service.findAll();

		// Then
		Assertions.assertThat(clearanceList).isNotNull();
		Assertions.assertThat(clearanceList.size()).isEqualTo(2);
	}

	@DisplayName("JUnit test for findAll method (negative scenario)")
	@Test
	public void givenEmptyClearancesList_whenGetAllClearances_thenReturnEmptyClearancesList() {
		// Given
		given(repository.findAll()).willReturn(Collections.emptyList());

		// When
		List<Clearance> clearanceList = service.findAll();

		// Then
		Assertions.assertThat(clearanceList).isEmpty();
		Assertions.assertThat(clearanceList.size()).isEqualTo(0);
	}

	@DisplayName("JUnit test for findById method")
	@Test
	public void givenClearanceId_whenGetClearanceById_thenReturnClearanceObject() {
		// Given
		given(repository.findById(1L)).willReturn(Optional.of(getDummyClearance()));

		// When
		Clearance foundClearance = service.findById(1L);

		// Then
		Assertions.assertThat(foundClearance).isNotNull();
	}

	@DisplayName("JUnit test for findById method Exception")
	@Test
	public void givenClearanceId_whenGetClearanceById_thenReturnException() {
		// Given
		given(repository.findById(1L)).willReturn(Optional.empty());

		// When & Then
		assertThrows(ResourceNotFoundException.class, () -> service.findById(1L));
	}

	@DisplayName("JUnit test for update method")
	@Test
	public void givenClearanceObject_whenUpdateClearance_thenReturnUpdatedClearance() {
		// Given
		Clearance clearance = getDummyClearance();
		given(repository.save(clearance)).willReturn(clearance);
		given(repository.findById(1L)).willReturn(Optional.of(clearance));
		clearance.setClearanceType("Updated Sale");
		clearance.setDiscount(30.0f);

		// When
		Clearance updatedClearance = service.update(clearance, 1L);

		// Then
		Assertions.assertThat(updatedClearance.getClearanceType()).isEqualTo("Updated Sale");
		Assertions.assertThat(updatedClearance.getDiscount()).isEqualTo(30.0f);
	}

	@DisplayName("JUnit test for deleteById method")
	@Test
	public void givenClearanceId_whenDeleteClearance_thenNothing() {
		// Given
		long Id = 1L;
		Clearance clearance = getDummyClearance();
		given(repository.findById(1L)).willReturn(Optional.of(clearance));
		willDoNothing().given(repository).delete(clearance);

		// When
		service.deleteById(Id);

		// Then
		verify(repository, times(1)).delete(clearance);
	}
}
