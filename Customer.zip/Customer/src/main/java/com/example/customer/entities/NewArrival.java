package com.example.customer.entities;

import java.util.Date;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

public class NewArrival {

	private long newArrivalId;
	private Date newArrivalDate;
	private String newArrivalType;
	private double price;

	public long getNewArrivalId() {
		return newArrivalId;
	}

	public void setNewArrivalId(long newArrivalId) {
		this.newArrivalId = newArrivalId;
	}

	public Date getNewArrivalDate() {
		return newArrivalDate;
	}

	public void setNewArrivalDate(Date newArrivalDate) {
		this.newArrivalDate = newArrivalDate;
	}

	public String getNewArrivalType() {
		return newArrivalType;
	}

	public void setNewArrivalType(String newArrivalType) {
		this.newArrivalType = newArrivalType;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
