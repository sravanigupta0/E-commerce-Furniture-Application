package com.example.customer.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.customer.dao.CustomerRepository;
import com.example.customer.dto.OrderDto;
import com.example.customer.entities.Clearance;
import com.example.customer.entities.Customer;
import com.example.customer.entities.Furniture;
import com.example.customer.entities.NewArrival;
import com.example.customer.service.CustomerService;
import com.example.customer.service.FurnitureFeignClient;
import com.example.customer.service.OrderFeignClient;
// Implementation of the CustomerService interface that handles customer-related operations
@Service
public class CustomerServiceImpl implements CustomerService {

	 // Repository for accessing customer data
	@Autowired
	CustomerRepository customerRepository;

	// Feign client for interacting with the Furniture service
	@Autowired
	FurnitureFeignClient furnitureFeignClient;

	// Feign client for interacting with the Order service
	@Autowired
	OrderFeignClient orderFeignClient;

	//Saves a new customer to the repository
	@Override
	public Customer save(Customer customer) {
		return customerRepository.save(customer);
	}

	//Retrieves all customers from the repository
	@Override
	public List<Customer> findAll() {
		return customerRepository.findAll();
	}

	//Finds a customer by their ID
	@Override
	public Customer findById(Long id) {
		return customerRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Resource for ID :" + id + " Not Available"));
	}

	//Deletes a customer by their ID.
	@Override
	public void deleteById(Long id) {
		Customer customer = findById(id);
		customerRepository.deleteById(id);
	}

	// Updates the details of an existing customer
	@Override
	public Customer UpdateById(Customer newData, Long id) {
		Customer oldData = findById(id);
		oldData.setCustomerName(newData.getCustomerName());
		oldData.setCustomerPhoneNumber(newData.getCustomerPhoneNumber());
		oldData.setCustomerAddress(newData.getCustomerAddress());
		oldData.setEmail(newData.getEmail());
		oldData.setPaymentMode(newData.getPaymentMode());
		return customerRepository.save(oldData);
	}

	// Retrieves all furniture items from the Furniture service
	@Override
	public List<Furniture> findAllFurnitures() {

		return furnitureFeignClient.getAllFurnitures();
	}

	// Retrieves all new arrivals from the Furniture service
	@Override
	public List<NewArrival> findAllNewArrivals() {

		return furnitureFeignClient.getAllNewArrivals();
	}

	//Retrieves all clearance items from the Furniture service
	@Override
	public List<Clearance> findAllClearances() {

		return furnitureFeignClient.getAllClearances();
	}

	//Saves an order through the Order service
	@Override
	public OrderDto saveOrder(OrderDto dto) {

		return orderFeignClient.save(dto);
	}
}
