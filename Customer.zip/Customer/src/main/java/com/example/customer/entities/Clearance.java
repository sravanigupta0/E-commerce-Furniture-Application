package com.example.customer.entities;

import java.util.Date;

public class Clearance {
	private Long clearanceId;
	private String clearanceType;
	private float discount;
	private Date clearanceDate;

	public Long getClearanceId() {
		return clearanceId;
	}

	public void setClearanceId(Long clearanceId) {
		this.clearanceId = clearanceId;
	}

	public String getClearanceType() {
		return clearanceType;
	}

	public void setClearanceType(String clearanceType) {
		this.clearanceType = clearanceType;
	}

	public float getDiscount() {
		return discount;
	}

	public void setDiscount(float discount) {
		this.discount = discount;
	}

	public Date getClearancedate() {
		return clearanceDate;
	}

	public void setClearancedate(Date clearancedate) {
		this.clearanceDate = clearancedate;
	}

}
