package com.example.customer.entities;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class Furniture {

	private Long furnitureId;

	private String furnitureName;

	private boolean availability;

	private double furniturePrice;

	public Long getFurnitureId() {
		return furnitureId;
	}

	public void setFurnitureId(Long furnitureId) {
		this.furnitureId = furnitureId;
	}

	public String getFurnitureName() {
		return furnitureName;
	}

	public void setFurnitureName(String furnitureName) {
		this.furnitureName = furnitureName;
	}

	public boolean isAvailability() {
		return availability;
	}

	public void setAvailability(boolean availability) {
		this.availability = availability;
	}

	public double getFurniturePrice() {
		return furniturePrice;
	}

	public void setFurniturePrice(double furniturePrice) {
		this.furniturePrice = furniturePrice;
	}

}
