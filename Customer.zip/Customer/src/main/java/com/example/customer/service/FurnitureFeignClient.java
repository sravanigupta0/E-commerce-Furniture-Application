package com.example.customer.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.customer.entities.Clearance;
import com.example.customer.entities.Furniture;
import com.example.customer.entities.NewArrival;

@FeignClient(name = "Admin", url = "http://localhost:8086/furnitures")
public interface FurnitureFeignClient {
 
	//Retrieves all furniture records
	@GetMapping("/findfurnitures")
	public List<Furniture> getAllFurnitures();
    
	//Retrieves all new arrival records
	@GetMapping("/newarrival/findarrival")
	public List<NewArrival> getAllNewArrivals();
    
    //Retrieves all clearance records
	@GetMapping("/clearance/findclearances")
	public List<Clearance> getAllClearances();
}
