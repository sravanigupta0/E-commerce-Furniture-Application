package com.example.customer.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;

@Entity // Indicates that this class is a JPA entity
@Table(name = "customer") // Specifies the name of the database table
public class Customer {

	@Id // Specifies the primary key of the entity
	@GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-generates the primary key value
	private Long customerId;

	@NotBlank(message = "Customer name must not be empty.") // Ensures the customer name is not empty
	private String customerName; 

	@NotBlank(message = "Customer address must not be empty.") // Ensures the customer address is not empty
	private String customerAddress; 

	@NotBlank(message = "Email must not be empty.") // Ensures the email is not empty
	@Email(message = "Email should be valid.") // Validates that the email format is correct
	private String email; 

	@NotNull(message = "Customer phone number must not be null.") // Ensures the phone number is not null
	@Pattern(regexp = "\\d{10}", message = "Phone number must be 10 digits.") // Validates that the phone number is
																				// exactly 10 digits
	private Long customerPhoneNumber; 

	@NotBlank(message = "Payment mode must not be empty.") // Ensures the payment mode is not empty
	private String paymentMode; 

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getCustomerPhoneNumber() {
		return customerPhoneNumber;
	}

	public void setCustomerPhoneNumber(Long customerPhoneNumber) {
		this.customerPhoneNumber = customerPhoneNumber;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

}
