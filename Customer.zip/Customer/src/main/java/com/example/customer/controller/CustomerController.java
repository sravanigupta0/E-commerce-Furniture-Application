package com.example.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.customer.dto.OrderDto;
import com.example.customer.entities.Clearance;
import com.example.customer.entities.Customer;
import com.example.customer.entities.Furniture;
import com.example.customer.entities.NewArrival;
import com.example.customer.service.CustomerService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/customers")
public class CustomerController {

	@Autowired
	CustomerService customerService;

	// Gets the customer service instance
	public CustomerService getCustomerService() {
		return customerService;
	}

	// Sets the customer service instance
	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}

	// Saves a new customer
	@PostMapping
	public ResponseEntity<Customer> save(@Valid @RequestBody Customer customer) {
		Customer c = customerService.save(customer);
		return new ResponseEntity<Customer>(c, HttpStatus.OK);
	}

	// Finds all customers
	// http://localhost:8094/customers/findcustomers
	@GetMapping("/findcustomers")
	public ResponseEntity<List<Customer>> findAll() {
		return new ResponseEntity<List<Customer>>(customerService.findAll(), HttpStatus.OK);
	}

	// Finds a customer by ID
	// http://localhost:8094/customers/findbyid
	@GetMapping("/findbyid/{id}")
	public ResponseEntity<Customer> findById(@PathVariable("id") Long id) {
		return new ResponseEntity<Customer>(customerService.findById(id), HttpStatus.OK);
	}

	// Updates a customer by ID
	// http://localhost:8094/customers/updatebyid/
	@PutMapping("/updatebyid/{id}")
	public ResponseEntity<Customer> updateById(@PathVariable("id") Long id, @Valid @RequestBody Customer newData) {
		return new ResponseEntity<Customer>(customerService.UpdateById(newData, id), HttpStatus.OK);
	}

	// Deletes a customer by ID
	// http://localhost:8094/customers/deletebyid/
	@DeleteMapping("/deletebyid/{id}")
	public ResponseEntity<HttpStatus> deleteById(@PathVariable("id") Long id) {
		customerService.deleteById(id);
		return new ResponseEntity<HttpStatus>(HttpStatusCode.valueOf(200));
	}

	// Finds all furnitures available
	// http://localhost:8094/customers/findfurnitures
	@GetMapping("/findfurnitures")
	public ResponseEntity<List<Furniture>> findAllFurnitures() {
		return new ResponseEntity<List<Furniture>>(customerService.findAllFurnitures(), HttpStatus.OK);
	}

	// Finds all new arrivals
	// http://localhost:8094/customers/findarrivals
	@GetMapping("/findarrivals")
	public ResponseEntity<List<NewArrival>> findAllNewArrivals() {
		return new ResponseEntity<List<NewArrival>>(customerService.findAllNewArrivals(), HttpStatus.OK);
	}

	// Finds all clearance items
	// http://localhost:8094/customers/findclearances
	@GetMapping("/findclearances")
	public ResponseEntity<List<Clearance>> findAllClearances() {
		return new ResponseEntity<List<Clearance>>(customerService.findAllClearances(), HttpStatus.OK);
	}

	// Places a new order
	// http://localhost:8094/customers/placeorder
	@PostMapping("/placeorder")
	public ResponseEntity<OrderDto> saveOrder(@Valid @RequestBody OrderDto dto) {
		return new ResponseEntity<OrderDto>(customerService.saveOrder(dto), HttpStatus.OK);
	}

}