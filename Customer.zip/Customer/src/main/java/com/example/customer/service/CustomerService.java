package com.example.customer.service;

import java.util.List;

import com.example.customer.dto.OrderDto;
import com.example.customer.entities.Clearance;
import com.example.customer.entities.Customer;
import com.example.customer.entities.Furniture;
import com.example.customer.entities.NewArrival;

public interface CustomerService {
    //Saves a new customer record
	Customer save(Customer customer);
     
	//Retrieves all customer records
	List<Customer> findAll();

	//Retrieves a customer record by its ID
	Customer findById(Long id);

	//Deletes a customer record by its ID
	void deleteById(Long id);
	
    //Updates an existing customer record
	Customer UpdateById(Customer newData, Long id);

	//Retrieves all furniture records.
	List<Furniture> findAllFurnitures();

	//Retrieves all new arrival records
	List<NewArrival> findAllNewArrivals();
    
	//Retrieves all clearance records
	List<Clearance> findAllClearances();
     
	//Saves a new order record.
	OrderDto saveOrder(OrderDto dto);
}
