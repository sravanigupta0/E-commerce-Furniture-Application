package com.example.customer.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.customer.dto.OrderDto;

import jakarta.validation.Valid;



@FeignClient(name="Orders",url="http://localhost:8087/orders")
public interface OrderFeignClient {
    
	//Saves a new order
	@PostMapping()
	 OrderDto save(@Valid @RequestBody OrderDto ord);
}
